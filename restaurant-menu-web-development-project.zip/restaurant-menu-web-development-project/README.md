# Restaurant Menu Web Development Project

A Pen created on CodePen.

Original URL: [https://codepen.io/Midnight083/pen/pvopMLV](https://codepen.io/Midnight083/pen/pvopMLV).

