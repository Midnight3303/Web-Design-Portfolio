# Navigation Bar Web Development Project

A Pen created on CodePen.

Original URL: [https://codepen.io/Midnight083/pen/QwWdgWY](https://codepen.io/Midnight083/pen/QwWdgWY).

