# Technical Documentation Page Web Development Project - freeCodeCamp

A Pen created on CodePen.

Original URL: [https://codepen.io/Midnight083/pen/XJWVEWp](https://codepen.io/Midnight083/pen/XJWVEWp).

