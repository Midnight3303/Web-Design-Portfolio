# Checkout Form Web Development Project

A Pen created on CodePen.

Original URL: [https://codepen.io/Midnight083/pen/LEYeKQB](https://codepen.io/Midnight083/pen/LEYeKQB).

