# Love Calculator Web Development Project

A Pen created on CodePen.

Original URL: [https://codepen.io/Midnight083/pen/NPPpezX](https://codepen.io/Midnight083/pen/NPPpezX).

